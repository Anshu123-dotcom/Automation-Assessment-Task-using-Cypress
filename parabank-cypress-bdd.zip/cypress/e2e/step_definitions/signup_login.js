import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import RegisterPage from "../../pages/RegisterPage";
import LoginPage from "../../pages/LoginPage";
import DashboardPage from "../../pages/DashboardPage";

const registerPage = new RegisterPage();
const loginPage = new LoginPage();
const dashboardPage = new DashboardPage();

let userData = {
  firstName: "John",
  lastName: "Doe",
  address: "123 Main St",
  city: "NYC",
  state: "NY",
  zip: "12345",
  phone: "1234567890",
  ssn: "98765",
  username: "user" + Date.now(),
  password: "Password123"
};

Given("I navigate to the Parabank registration page", () => {
  cy.visit("/register.htm");
});

When("I fill the registration form with valid data", () => {
  registerPage.fillForm(userData);
});

When("I submit the registration form", () => {
  registerPage.submitForm();
});

Then("I should see the registration success message", () => {
  cy.contains("Your account was created successfully. You are now logged in.").should("be.visible");
});

Given("I navigate to the Parabank login page", () => {
  cy.visit("/");
});

When("I login with the registered credentials", () => {
  loginPage.login(userData.username, userData.password);
});

Then("I should be redirected to the dashboard", () => {
  cy.contains("Accounts Overview").should("be.visible");
});

Then("I should see the account balance displayed", () => {
  dashboardPage.getBalance().then(balance => {
    cy.log("Account Balance is: " + balance);
  });
});
